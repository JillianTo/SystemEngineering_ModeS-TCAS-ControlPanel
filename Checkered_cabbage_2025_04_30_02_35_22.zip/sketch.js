let aircraft = [
  { x: 30, y: 40, z: 14000, dx: 0.3, dy: 0.2, dz: 5 },
  { x: 35, y: 45, z: 13500, dx: -0.2, dy: 0.3, dz: -3 },
  { x: 60, y: 80, z: 10500, dx: -0.3, dy: -0.4, dz: 2 }
];

let ownID = 0;

function setup() {
  createCanvas(600, 600);
  frameRate(1);
  textFont('monospace');
}

function draw() {
  background(255);
  drawGrid();
  drawAircraft();
  drawAdvisories();
  updatePositions();
}

function drawGrid() {
  stroke(200);
  for (let i = 0; i <= 100; i += 10) {
    line(i * 5, 0, i * 5, height);
    line(0, i * 5, width, i * 5);
  }
  stroke(0);
  fill(0);
  textAlign(LEFT);
  text('Control Mode: Stand-by', 20, 20);
}

function drawAircraft() {
  for (let i = 0; i < aircraft.length; i++) {
    let a = aircraft[i];
    let px = a.x * 5;
    let py = height - a.y * 5;

    if (i === ownID) {
      fill(0);
      triangle(px, py - 10, px - 7, py + 7, px + 7, py + 7);
    } else {
      let d = dist(aircraft[ownID].x, aircraft[ownID].y, a.x, a.y);
      let dz = aircraft[ownID].z - a.z;

      if (d < 10 && abs(dz) < 1000) {
        fill(255, 0, 0);
        rect(px - 8, py - 8, 16, 16);
        fill(0);
        textAlign(LEFT);
        text(`${dz} ft`, px + 10, py);
      } else if (d < 15 && abs(dz) < 2000) {
        fill(255, 255, 0);
        ellipse(px, py, 20, 20);
        fill(0);
        textAlign(LEFT);
        text(`${nf(d, 1, 1)} nmi`, px + 10, py);
      } else {
        noFill();
        stroke(0);
        beginShape();
        vertex(px, py - 10);
        vertex(px + 10, py);
        vertex(px, py + 10);
        vertex(px - 10, py);
        endShape(CLOSE);
      }
    }
  }
}

function drawAdvisories() {
  fill(0);
  textAlign(LEFT);
  text('Advisory:', 20, height - 40);
  let advisory = '';
  for (let i = 0; i < aircraft.length; i++) {
    if (i !== ownID) {
      let d = dist(aircraft[ownID].x, aircraft[ownID].y, aircraft[i].x, aircraft[i].y);
      let dz = aircraft[ownID].z - aircraft[i].z;
      if (d < 10 && abs(dz) < 1000) {
        advisory += `RA ${nf(d,1,1)} nmi, ${dz} ft\n`;
      } else if (d < 15 && abs(dz) < 2000) {
        advisory += `TA ${nf(d,1,1)} nmi, ${dz} ft\n`;
      }
    }
  }
  text(advisory, 20, height - 25);
}

function updatePositions() {
  for (let a of aircraft) {
    a.x += a.dx;
    a.y += a.dy;
    a.z += a.dz;
  }
}
